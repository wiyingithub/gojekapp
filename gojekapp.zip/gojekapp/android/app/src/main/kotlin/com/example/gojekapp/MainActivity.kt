package com.example.gojekapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
